let wrapper = document.querySelector('.wrapper');


fetch('https://dummyjson.com/products')
    .then(res => res.json())
    .then((data) => {
        // Start here :)
        const products = data.products;
        console.log(products);
        products.forEach(product => {
            let { images, title, description, price, rating } = product;

            wrapper.innerHTML += `<div class="card cardBox" >
            <div class = "card-img"><img src="${images[0]}" class= "image" alt=""></div>
            <div class="card-body">
            <h5 class="card-title">${title}</h5>
            <p class="card-text">${description}</p>
            </div>
            <div class="card-footer cardFoot">
            <span class="cardPrice"> Price: ${price}</span>
            <span class="cardRating"> Rating: ${rating}</span>
            </div></div>`

        })

    });